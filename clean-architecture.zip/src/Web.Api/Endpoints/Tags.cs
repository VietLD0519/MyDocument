﻿namespace Web.Api.Endpoints;

public static class Tags
{
    public const string Users = "Users";
    public const string Todos = "todos";
}
