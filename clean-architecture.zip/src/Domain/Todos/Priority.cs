﻿namespace Domain.Todos;

public enum Priority
{
    Normal = 0,
    Low = 1,
    Medium = 2,
    High = 3,
    Top = 4
}
